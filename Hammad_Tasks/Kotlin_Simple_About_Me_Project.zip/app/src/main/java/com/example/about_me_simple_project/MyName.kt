package com.example.about_me_simple_project

data class MyName(var name: String="",var nickName: String="")
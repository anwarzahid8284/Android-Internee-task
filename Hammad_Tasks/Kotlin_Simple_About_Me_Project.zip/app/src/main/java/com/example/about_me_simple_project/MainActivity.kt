package com.example.about_me_simple_project

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil
import com.example.about_me_simple_project.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private  lateinit var binding: ActivityMainBinding

    private  var myName: MyName= MyName("Ahmad")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        //setContentView(R.layout.activity_main) xml ko connect krne keleye use keya ta lekin ab ham binding ke through connect krte he xml ko

       binding= DataBindingUtil.setContentView<ActivityMainBinding>(this,R.layout.activity_main)
        binding.myName=myName

        binding.buttonAboutMe.setOnClickListener {
            addToNickName(it)
        }


        }

    private fun  addToNickName(view: View){

        binding.apply {
            //nameText.text = binding.editText.text
            myName?.nickName=EditText.text.toString()
            invalidateAll()
            EditText.visibility = View.GONE
            buttonAboutMe.visibility = View.GONE
            nickNameText.visibility = View.VISIBLE

        }
        view.visibility= View.GONE

        val imm=getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        imm.hideSoftInputFromWindow(view.windowToken,0)
    }
}
package com.example.dice_roller

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Random

class MainActivity : AppCompatActivity() {

    lateinit var  imageOfDice: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        imageOfDice=findViewById<ImageView>(R.id.empDice)

        val myButton=findViewById<Button>(R.id.button1)

        myButton.setOnClickListener {

            diceRoller()
        }



        }

    fun diceRoller(){
        val currentDice=  when(Random().nextInt(6)+1){
            1 -> R.drawable.dice1
            2 -> R.drawable.dice2
            3 -> R.drawable.dice3
            4 -> R.drawable.dice4
            5 -> R.drawable.dice5
            else -> R.drawable.dice6
        }
        imageOfDice.setImageResource(currentDice)
    }
}

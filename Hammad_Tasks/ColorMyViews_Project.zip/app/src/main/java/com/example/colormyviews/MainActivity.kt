package com.example.colormyviews

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.colormyviews.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        // to call clickableView function

        clickableView()

    }

    private fun clickableView() {
        val clickableView: List<View> = listOf(
        binding.boxTextOne,
            binding.BoxTwoText ,
            binding.boxThreeText ,
            binding.boxTextFour ,
            binding.boxTextFive ,
            binding.button ,
            binding.button3 ,
            binding.button4 ,
            binding.Constrtaint
        )

        for (item in clickableView){
            item.setOnClickListener { makeColor(it) }
    }
}

    fun makeColor(view: View) {
        when(view.id){
            binding.boxTextOne.id -> view.setBackgroundResource(R.color.box_1)
            binding.BoxTwoText.id -> view.setBackgroundResource(R.color.box_2)
            binding.boxThreeText.id -> view.setBackgroundResource(R.color.box_3)
            binding.boxTextFour.id -> view.setBackgroundResource(R.color.box_4)
            binding.boxTextFive.id -> view.setBackgroundResource(R.color.box_5)

            binding.button.id -> binding.boxThreeText.setBackgroundResource(R.color.red_color)
            binding.button3.id -> binding.boxTextFour.setBackgroundResource(R.color.green_color)
            binding.button4.id -> binding.boxTextFive.setBackgroundResource(R.color.yellow_color)

            else -> binding.Constrtaint.setBackgroundResource(R.color.background_color)
        }
    }

}
